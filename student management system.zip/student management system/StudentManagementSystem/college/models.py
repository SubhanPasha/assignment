from django.db import models

# Create your models here.
class Teacher(models.Model):
    name = models.CharField(max_length=15)
    subject = models.CharField(max_length=10)
    lec_class = models.CharField(max_length=10)       
    lec_time = models.TimeField()
    date = models.DateField()

    class Meta:
        managed = False
        db_table = 'teacher'



class Student(models.Model):
    name = models.CharField(max_length=15)
    roll_no = models.CharField(max_length=10)
    student_class = models.CharField(max_length=10)      
    address = models.CharField(max_length=30)
    gender = models.CharField(max_length=10)
    attendance = models.CharField(max_length=5)
    teacher = models.ForeignKey(Teacher, on_delete=models.CASCADE)

    class Meta:
        managed = False
        db_table = 'student'


class Course(models.Model):
    course_name = models.CharField(max_length=20)
    teacher = models.ManyToManyField(Teacher)
    

    class Meta:
        managed = False
        db_table = 'course'
