from django.contrib import admin
from django.contrib.admin.options import ModelAdmin
from .models import *

# Register your models here.
@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ['name','subject','lec_class','lec_time','date']

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ['name','roll_no','student_class','address','gender','attendance']


@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['course_name']