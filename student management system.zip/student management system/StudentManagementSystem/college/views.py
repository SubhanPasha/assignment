from django.db.models.query import QuerySet
from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.db.models import Q
from .models import *

# Create your views here.
def studentTable(request):
    ab = Student.objects.all()
    fil = Teacher.objects.all()
    
    d = {"all":ab,'t':fil}
    return render(request,'teacher/index.html',d)

def teacherFilter(request):
    teacher_ob= request.POST['teacher']
    rel_data = Student.objects.filter(teacher__name=teacher_ob)
    fil = Teacher.objects.all()
    d = {'all':rel_data,'t':fil}
    return render(request,'teacher/filter_by_teacher.html',d)

def delete1(request,id):
    a = Student.objects.get(id=id)
    a.delete()
    
    return HttpResponseRedirect('/')


def courseFilter(request):
    teacher_ob= request.POST['teacher']
    teacher_class_ob= request.POST['class']
    fil = Teacher.objects.all()
    rel_data = Student.objects.filter(Q(teacher__name=teacher_ob) & Q(student_class=teacher_class_ob))
    d = {'all':rel_data,'t':fil}
    return render(request,'teacher/filter_by_teacher.html',d)



    