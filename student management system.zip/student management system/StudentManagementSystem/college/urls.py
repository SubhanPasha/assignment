
from django.urls import path
from .views import *

urlpatterns = [
  
    path('',studentTable),
    path('techer-filter',teacherFilter),
     path('delete1/<int:id>', delete1),
     path('course-filter', courseFilter),
]