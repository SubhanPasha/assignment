from django.db import models
from django.db.models.fields import CharField

# Create your models here.
class Writter(models.Model):
    id = models.IntegerField(primary_key=True)
    name =  models.CharField(max_length=20)
    def __str__(self):
        return self.name
    
class Book(models.Model):
    id = models.IntegerField(primary_key=True)
    songs = models.CharField(max_length=20)
    duration = models.CharField(max_length=10)
    writter = models.ManyToManyField(Writter)

class MyappBookWritter(models.Model):
    id = models.IntegerField(primary_key=True)
    book = models.ForeignKey(Book, on_delete=models.DO_NOTHING) 
    writter = models.ForeignKey(Writter,on_delete=models.DO_NOTHING)

    class Meta:
        managed = False
        db_table = 'myapp_book_writter'
        unique_together = (('book', 'writter'),)