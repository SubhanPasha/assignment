from django.shortcuts import render
from django.http import HttpResponse
from . models import *

# Create your views here.
def home(request):
    if request.method == 'POST':
        name = request.POST['name']
        Writter(name = name).save()
        return HttpResponse('added successfullly')

    return render(request,'index.html')

def book(request):
    if request.method == 'POST':
        name = request.POST['name']
        adition = request.POST['adition']
        writter1 = request.POST.getlist('writter')
        ob = Book.objects.create(songs=name,duration=adition)
        for e in writter1:
            ob.writter.add(Writter.objects.get(id=e))

        return HttpResponse('Book added successfullly')

    return render(request,'book.html',{'all':Writter.objects.all()})

def show(request):
    books = Book.objects.raw('SELECT myapp_book.songs,myapp_book.duration,myapp_writter.name FROM myapp_book INNER JOIN myapp_book_writter ON myapp_book.id = myapp_book_writter.book_id INNER JOIN myapp_writter ON myapp_writter.id = myapp_book_writter.writter_id')
    print(books.myapp_book.songs)
       

    
    return render(request,'show.html',)