from django.contrib import admin
from .models import * 

# Register your models here.
@admin.register(Writter)
class AdminWritter(admin.ModelAdmin):
    list_display = ['name']


@admin.register(Book)
class AdminBook(admin.ModelAdmin):
    list_display = ['songs','duration']
