import json
key  = [1,2,3]
value = ['subhan','manish','kusal']
table = []

for i in value:
    table.append(json.dumps({'name':f'{i}'}))
print(table)