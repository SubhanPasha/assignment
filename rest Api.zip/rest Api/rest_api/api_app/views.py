from django.http.response import HttpResponse
from django.shortcuts import render
from .serializers import *
from rest_framework.renderers import JSONRenderer
from .models import *
from django.views.decorators.csrf import csrf_exempt
import io
from rest_framework.parsers import JSONParser
# Create your views here.
def apiView(request):
    d =[]
    q  = Student.objects.all()
    for i in q:
        d.append({'name':i.name,'rollno':i.roll_no,'course':i.course})
    # print(d)
    # ser = StudentSerializer(q,many=True)
    json_data = JSONRenderer().render(d)
    return HttpResponse(json_data,content_type='application/json')

@csrf_exempt
def apiPost(request):
    if request.method == 'POST':
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        # print(python_data)
        # ser = StudentSerializer(data=python_data)
        # if ser.is_valid():
        #     ser.save()
        list_data = []
        for i in python_data.values():
            list_data.append(i)
        # print(list_data)    
        Student(name=list_data[0],roll_no=list_data[1],course=list_data[2]).save()

        return HttpResponse("added succesfully")

@csrf_exempt
def apiPut(request):
    if request.method == 'PUT':
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        # print(python_data)
        # ser = StudentSerializer(data=python_data)
        # if ser.is_valid():
        #     ser.save()
        list_data = []
        for i in python_data.values():
            list_data.append(i)
        # print(list_data)   
        Student(id=list_data[0],name=list_data[1],roll_no=list_data[2],course=list_data[3]).save()

        return HttpResponse("updated succesfully")

@csrf_exempt
def apiDelete(request):
    if request.method == "DELETE":
        json_data = request.body
        stream = io.BytesIO(json_data)
        python_data = JSONParser().parse(stream)
        # print(python_data)
        id = python_data.get('id')
        # print(id)
        Student.objects.get(id = id).delete()
        return HttpResponse("deteted succesfully")