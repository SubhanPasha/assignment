from rest_framework import serializers
from .models import *

class StudentSerializer(serializers.Serializer):
   
    name = serializers.CharField(max_length=20)
    roll_no = serializers.CharField(max_length=20)
    course = serializers.CharField(max_length=20)

    def create(self, validate_data):
        return Student.objects.create(**validate_data)
