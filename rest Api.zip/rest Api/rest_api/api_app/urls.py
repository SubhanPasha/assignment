
from django.urls import path
from .views import *

urlpatterns = [
    
    path('api',apiView),
    path('api-post',apiPost),
    path('api-put',apiPut),
    path('api-delete',apiDelete),

]
